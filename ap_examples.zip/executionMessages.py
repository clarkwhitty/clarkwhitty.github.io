import time
import os

print(os.environ)

for i in range(0,10):
  print("INFO: counter i is " + str(i))
  time.sleep(float(os.environ['VELOCITY_PARAM_input_sleep']))




