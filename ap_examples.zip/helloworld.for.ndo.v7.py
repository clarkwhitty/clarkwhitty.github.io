import sys
import argparse
import time

parser = argparse.ArgumentParser()
parser.add_argument('-input_sleep', action='store', dest='sleep', help='sleep time')
results, unknown = parser.parse_known_args()

print('Sleeping for '+str(results.sleep)+' seconds...')
time.sleep(int(results.sleep))
print('Final message: Hello World!')
