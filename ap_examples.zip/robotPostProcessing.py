import time
import datetime
import subprocess

f=open("debug.txt","r")
print(f.read())

timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d_%H:%M:%S')

subprocess.call(['ssh', '-i', '/home/agent/.ssh/id_rsa', 'spirent@ps-lab-ubuntu-2.spirenteng.com', 'mkdir', '/var/www/robot/' + timestamp])

subprocess.call(['scp', '-i', '/home/agent/.ssh/id_rsa', 'debug.txt', 'output.xml', 'log.html', 'report.html', 'spirent@ps-lab-ubuntu-2.spirenteng.com:/var/www/robot/' + timestamp])

print('- INFO - Published reports to: http://ps-lab-ubuntu-2.spirenteng.com/robot/' + timestamp)
